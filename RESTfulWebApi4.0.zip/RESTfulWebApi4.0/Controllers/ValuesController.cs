﻿using Newtonsoft.Json;
using RESTfulWebApi4.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Threading.Tasks;
using System.Web.Http;

namespace RESTfulWebApi4.Controllers
{
    public class ValuesController : ApiController
    {
        static readonly HttpClient client = new HttpClient();

        [HttpGet]
        public async Task<City> Get(string id)
        {
            string uri = $"https://dawa.aws.dk/postnumre/{id}";

            string responseBody = await client.GetStringAsync(uri);

            return JsonConvert.DeserializeObject<City>(responseBody);
        }
    }
}


