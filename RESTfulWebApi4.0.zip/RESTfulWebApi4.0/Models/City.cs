﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace RESTfulWebApi4.Models
{
    public class City
    {
        public int Nr { set; get; }
        public string Navn { set; get; }
    }
}